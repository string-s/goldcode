"""参赛者只需要修改这个文件。

这里附带一个可直接运行的基准策略：
- hunter：优先追逐金萝卜，否则追逐最近的存活对手；
- runner：优先追逐金萝卜，否则尽量远离最近的存活对手；
- 靠近地图边缘时，两种模式都会先返回场地中心。

可通过 BOT_STYLE=hunter 或 BOT_STYLE=runner 选择风格，默认 hunter。
"""

import math
import os

STRATEGY_IMPLEMENTED = True
STYLE = "runner" if os.environ.get("BOT_STYLE") == "runner" else "hunter"

_decision_count = 0


def _number(value, default=0.0):
    """等价于 JS 的 Number(...)：无法解析或不是有限值时返回 default。"""
    try:
        result = float(value)
    except (TypeError, ValueError):
        return default
    return result if math.isfinite(result) else default


def _normalized_angle(value):
    angle = value
    while angle > math.pi:
        angle -= math.pi * 2
    while angle < -math.pi:
        angle += math.pi * 2
    return angle


def _distance_squared(left, right):
    dx = _number(left["position"].get("x")) - _number(right["position"].get("x"))
    dy = _number(left["position"].get("y")) - _number(right["position"].get("y"))
    return dx * dx + dy * dy


def _is_active(rabbit):
    active = rabbit.get("active")
    return active is not False and active != "false"


def _find_me(rabbits, bot_id):
    expected = str(bot_id)
    for rabbit in rabbits:
        rabbit_id = str(rabbit.get("id"))
        # ai: 前缀兼容本地 sample 服务；生产协议通常直接使用 botId。
        if rabbit_id == expected or rabbit_id == "ai:" + expected:
            return rabbit
    return None


def _choose_target(game_state, me, rabbits):
    carrot = game_state.get("goldCarrot") if isinstance(game_state, dict) else None
    if isinstance(carrot, dict):
        carrot_x = _number(carrot.get("x"))
        carrot_y = _number(carrot.get("y"))
        if carrot_x > 0 and carrot_y > 0:
            return {"position": {"x": carrot_x, "y": carrot_y}}

    x = _number(me["position"].get("x"))
    y = _number(me["position"].get("y"))
    edge_margin = 150
    if x < edge_margin or x > 1440 - edge_margin or y < edge_margin or y > 820 - edge_margin:
        return {"position": {"x": 720, "y": 410}}

    opponents = [
        rabbit for rabbit in rabbits
        if rabbit is not me and _is_active(rabbit) and isinstance(rabbit.get("position"), dict)
    ]
    opponents.sort(key=lambda rabbit: _distance_squared(rabbit, me))
    if not opponents:
        return {"position": {"x": 720, "y": 410}}
    nearest = opponents[0]

    if STYLE == "runner":
        return {
            "position": {
                "x": 1440 - _number(nearest["position"].get("x")),
                "y": 820 - _number(nearest["position"].get("y")),
            },
        }
    return nearest


def choose_command(game_state, bot_id):
    """每约 100ms 调用一次，每次最多返回一个动作。

    :param game_state: 服务端最新 refreshData.data（dict）
    :param bot_id: 服务端 botConnected 返回的本人 BOT ID
    :return: {"commandType": str, "data": str（可选）}
    """
    global _decision_count
    _decision_count += 1

    rabbits = game_state.get("rabbits") if isinstance(game_state, dict) else None
    if not isinstance(rabbits, list):
        rabbits = []
    me = _find_me(rabbits, bot_id)

    # 本人不存在或已淘汰时必须停止，避免向房间发送无效动作。
    position = me.get("position") if isinstance(me, dict) else None
    if me is None or not _is_active(me) or not isinstance(position, dict) \
            or _number(position.get("x"), None) is None \
            or _number(position.get("y"), None) is None:
        return {"commandType": "stop"}

    target = _choose_target(game_state, me, rabbits)
    desired_angle = math.atan2(
        _number(target["position"].get("y")) - _number(position.get("y")),
        _number(target["position"].get("x")) - _number(position.get("x")),
    )
    current_angle = _number(me.get("angle"))
    delta = _normalized_angle(desired_angle - current_angle)

    if abs(delta) > 0.18:
        return {
            "commandType": "turnRight" if delta > 0 else "turnLeft",
            "data": "0.065" if STYLE == "runner" else "0.05",
        }
    # 转向指令会持续生效，周期性回正后再继续前进。
    if _decision_count % 7 == 0:
        return {"commandType": "steerBack"}
    return {"commandType": "goForward"}
