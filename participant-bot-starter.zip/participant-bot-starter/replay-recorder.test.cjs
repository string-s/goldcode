'use strict';

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const {
  REPLAY_FILE_NAME,
  REPLAY_FORMAT,
  REPLAY_VERSION,
  ReplayRecorder,
} = require('./replay-recorder.cjs');

const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'crazy-crash-replay-'));

try {
  const recorder = new ReplayRecorder({
    directory,
    meta: {
      matchCode: 'test-r01-t01',
      matchId: 77,
      roomId: 'test-r01-t01',
      recorderBot: { id: 1001, name: '测试参赛队', attackValue: 999 },
    },
  });

  recorder.start({
    commandType: 'startGame',
    timeStamp: 1000,
    data: {
      rabbits: [{
        id: 1001,
        position: { x: 720, y: 410 },
        attackValue: 50,
      }],
      map: { width: 1440, height: 820 },
    },
  }, 1100);
  recorder.frame({
    commandType: 'refreshData',
    timestamp: 1100,
    data: {
      rabbits: [{
        id: 1001,
        position: { x: 725, y: 410 },
        energy: 950,
        score: 10,
        attackValue: 50,
      }],
      remainingTime: 180,
      elapsedSeconds: 0,
    },
  }, 1210);
  recorder.frame({
    commandType: 'refreshData',
    timestamp: 1200,
    data: {
      rabbits: [{
        id: 1001,
        position: { x: 730, y: 410 },
        energy: 900,
        score: 11,
        nested: { attackValue: 700 },
      }],
      remainingTime: 179,
      elapsedSeconds: 1,
    },
  }, 1320);

  const replayPath = recorder.close(1500);
  assert.strictEqual(path.basename(replayPath), REPLAY_FILE_NAME);
  assert.strictEqual(fs.existsSync(`${replayPath}.tmp`), false, 'atomic temp file must be renamed');

  const incomplete = JSON.parse(fs.readFileSync(replayPath, 'utf8'));
  assert.strictEqual(incomplete.format, REPLAY_FORMAT);
  assert.strictEqual(incomplete.version, REPLAY_VERSION);
  assert.strictEqual(incomplete.end.complete, false);
  assert.deepStrictEqual(incomplete.frames.map(frame => frame.atMs), [100, 200]);
  assert.strictEqual(JSON.stringify(incomplete).includes('attackValue'), false);

  recorder.settle({
    commandType: 'matchFinished',
    result: {
      ranking: [{
        botId: 1001,
        rank: 1,
        score: 11,
        attackValue: 1000,
      }],
    },
  });
  const complete = JSON.parse(fs.readFileSync(replayPath, 'utf8'));
  assert.strictEqual(complete.end.complete, true);
  assert.strictEqual(complete.end.rankings[0].rank, 1);
  assert.strictEqual(JSON.stringify(complete).includes('attackValue'), false);

  console.log('replay recorder tests passed');
} finally {
  fs.rmSync(directory, { recursive: true, force: true });
}
