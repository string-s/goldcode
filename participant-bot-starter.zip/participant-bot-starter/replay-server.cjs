'use strict';

const fs = require('node:fs');
const http = require('node:http');
const https = require('node:https');
const path = require('node:path');

const DEFAULT_PORT = 9998;
const CDN_ROOT = 'https://dev.g.alicdn.com/pengtianshun.pts/crazy-crash/0.0.1';
const HTML_FILE = path.join(__dirname, 'replay.html');
const FORWARDED_HEADERS = [
  'accept-ranges',
  'cache-control',
  'content-length',
  'content-type',
  'etag',
  'last-modified',
];

function cdnAssetUrl(requestUrl) {
  const url = new URL(requestUrl, 'http://127.0.0.1');
  if (!url.pathname.startsWith('/build/')) {
    return null;
  }

  let assetName;
  try {
    assetName = decodeURIComponent(url.pathname.slice('/build/'.length));
  } catch (error) {
    return null;
  }

  if (!/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(assetName)) {
    return null;
  }
  return `${CDN_ROOT}/${encodeURIComponent(assetName)}`;
}

function sendText(response, statusCode, body) {
  response.writeHead(statusCode, {
    'Content-Type': 'text/plain; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
  });
  response.end(body);
}

function serveHtml(request, response, url) {
  if (url.pathname !== '/game' || url.searchParams.get('mode') !== 'replay') {
    url.pathname = '/game';
    url.searchParams.set('mode', 'replay');
    response.writeHead(302, {
      Location: `${url.pathname}${url.search}`,
    });
    response.end();
    return;
  }

  fs.readFile(HTML_FILE, (error, html) => {
    if (error) {
      sendText(response, 500, `无法读取 replay.html：${error.message}`);
      return;
    }
    response.writeHead(200, {
      'Content-Type': 'text/html; charset=utf-8',
      'Content-Length': html.length,
      'Cache-Control': 'no-store',
    });
    response.end(request.method === 'HEAD' ? undefined : html);
  });
}

function proxyAsset(request, response, targetUrl) {
  const upstream = https.request(targetUrl, {
    method: request.method,
    headers: {
      'User-Agent': 'crazy-crash-local-replay/1.0',
    },
  }, (upstreamResponse) => {
    const headers = {};
    FORWARDED_HEADERS.forEach((name) => {
      if (upstreamResponse.headers[name] !== undefined) {
        headers[name] = upstreamResponse.headers[name];
      }
    });
    response.writeHead(upstreamResponse.statusCode || 502, headers);
    upstreamResponse.pipe(response);
  });

  upstream.setTimeout(15000, () => {
    upstream.destroy(new Error('CDN 请求超时'));
  });
  upstream.on('error', (error) => {
    if (!response.headersSent) {
      sendText(response, 502, `CDN 素材加载失败：${error.message}`);
    } else {
      response.destroy(error);
    }
  });
  upstream.end();
}

function createServer() {
  return http.createServer((request, response) => {
    if (request.method !== 'GET' && request.method !== 'HEAD') {
      sendText(response, 405, '只支持 GET 和 HEAD 请求');
      return;
    }

    const url = new URL(request.url, 'http://127.0.0.1');
    const assetUrl = cdnAssetUrl(request.url);
    if (assetUrl) {
      proxyAsset(request, response, assetUrl);
      return;
    }

    if (
      url.pathname === '/' ||
      url.pathname === '/game' ||
      url.pathname === '/game/' ||
      url.pathname === '/replay.html'
    ) {
      serveHtml(request, response, url);
      return;
    }

    sendText(response, 404, '未找到');
  });
}

if (require.main === module) {
  const parsedPort = Number(process.env.REPLAY_PORT || DEFAULT_PORT);
  if (!Number.isInteger(parsedPort) || parsedPort < 1 || parsedPort > 65535) {
    console.error('REPLAY_PORT 必须是 1 到 65535 之间的整数');
    process.exitCode = 1;
  } else {
    createServer().listen(parsedPort, '127.0.0.1', () => {
      console.log(`本地回放页：http://127.0.0.1:${parsedPort}/game?mode=replay`);
      console.log('按 Ctrl+C 停止服务');
    });
  }
}

module.exports = {
  CDN_ROOT,
  DEFAULT_PORT,
  cdnAssetUrl,
  createServer,
};
