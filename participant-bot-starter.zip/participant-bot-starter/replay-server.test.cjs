'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {
  CDN_ROOT,
  cdnAssetUrl,
} = require('./replay-server.cjs');

assert.equal(
  cdnAssetUrl('/build/013787b6d91844317eb77df199481c7d.png'),
  `${CDN_ROOT}/013787b6d91844317eb77df199481c7d.png`
);
assert.equal(
  cdnAssetUrl('/build/game.mp3?cache=1'),
  `${CDN_ROOT}/game.mp3`
);
assert.equal(cdnAssetUrl('/build/../secret.txt'), null);
assert.equal(cdnAssetUrl('/build/%2e%2e%2fsecret.txt'), null);
assert.equal(cdnAssetUrl('/build/nested/asset.png'), null);
assert.equal(cdnAssetUrl('/other/asset.png'), null);
assert.equal(cdnAssetUrl('/build/'), null);

const html = fs.readFileSync(path.join(__dirname, 'replay.html'), 'utf8');
assert.match(
  html,
  /https:\/\/dev\.g\.alicdn\.com\/pengtianshun\.pts\/crazy-crash\/0\.0\.1/
);
assert.match(html, /current\.pathname = '\/game'/);
assert.match(html, /searchParams\.set\('mode', 'replay'\)/);
assert.match(html, /id="game-content"/);
assert.match(html, /PUBLIC_PATH_MARKER = 'i\.p="\/build\/"'/);
assert.match(html, /var GAME_PATH_MARKER/);

console.log('Replay server tests passed.');
