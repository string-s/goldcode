'use strict';

const fs = require('fs');
const path = require('path');

const REPLAY_FORMAT = 'crazy-crash-replay';
const REPLAY_VERSION = 1;
const REPLAY_FILE_NAME = 'replay.ccreplay.json';

function isObject(value) {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function withoutAttackValue(value) {
  if (Array.isArray(value)) return value.map(withoutAttackValue);
  if (!isObject(value)) return value;
  return Object.keys(value).reduce((result, key) => {
    if (key !== 'attackValue') result[key] = withoutAttackValue(value[key]);
    return result;
  }, {});
}

function finiteTimestamp(...values) {
  for (const value of values) {
    const parsed = Number(value);
    if (Number.isFinite(parsed) && parsed >= 0) return parsed;
  }
  return null;
}

function rankingsFromSettlement(message) {
  if (Array.isArray(message && message.rankings)) return message.rankings;
  if (message && message.result && Array.isArray(message.result.ranking)) {
    return message.result.ranking;
  }
  return [];
}

class ReplayRecorder {
  constructor(options) {
    if (!options || !options.directory) {
      throw new Error('ReplayRecorder.directory is required');
    }
    this.filePath = path.join(options.directory, REPLAY_FILE_NAME);
    this.meta = withoutAttackValue(options.meta || {});
    this.startState = { rabbits: [] };
    this.frames = [];
    this.startReceivedAt = null;
    this.startSourceAt = null;
    this.closedAtMs = 0;
    this.lastAtMs = 0;
    this.complete = false;
    this.rankings = [];
  }

  start(message, receivedAt = Date.now()) {
    this.startReceivedAt = finiteTimestamp(receivedAt, Date.now());
    this.startSourceAt = finiteTimestamp(
      message && message.timeStamp,
      message && message.timestamp,
      this.startReceivedAt,
    );
    this.startState = withoutAttackValue(message && message.data || { rabbits: [] });
  }

  frame(message, receivedAt = Date.now()) {
    const atMs = this.relativeTime(message, receivedAt);
    this.frames.push({
      atMs,
      state: withoutAttackValue(message && message.data || { rabbits: [] }),
    });
    this.lastAtMs = atMs;
  }

  close(receivedAt = Date.now()) {
    this.closedAtMs = Math.max(this.lastAtMs, this.receivedRelativeTime(receivedAt));
    this.complete = false;
    this.rankings = [];
    this.write();
    return this.filePath;
  }

  settle(message) {
    this.complete = true;
    this.rankings = withoutAttackValue(rankingsFromSettlement(message));
    this.write();
    return this.filePath;
  }

  snapshot() {
    return {
      format: REPLAY_FORMAT,
      version: REPLAY_VERSION,
      meta: this.meta,
      start: this.startState,
      frames: this.frames,
      end: {
        atMs: Math.max(this.closedAtMs, this.lastAtMs),
        complete: this.complete,
        rankings: this.rankings,
      },
    };
  }

  relativeTime(message, receivedAt) {
    const sourceAt = finiteTimestamp(message && message.timestamp, message && message.timeStamp);
    const sourceDelta = sourceAt == null || this.startSourceAt == null
      ? null
      : sourceAt - this.startSourceAt;
    const receivedDelta = this.receivedRelativeTime(receivedAt);
    const candidate = sourceDelta != null && sourceDelta >= 0
      ? sourceDelta
      : receivedDelta;
    return Math.max(this.lastAtMs, Math.round(candidate));
  }

  receivedRelativeTime(receivedAt) {
    const current = finiteTimestamp(receivedAt, Date.now());
    if (this.startReceivedAt == null) return 0;
    return Math.max(0, Math.round(current - this.startReceivedAt));
  }

  write() {
    const temporaryPath = `${this.filePath}.tmp`;
    fs.writeFileSync(temporaryPath, `${JSON.stringify(this.snapshot(), null, 2)}\n`, 'utf8');
    fs.renameSync(temporaryPath, this.filePath);
  }
}

module.exports = {
  REPLAY_FILE_NAME,
  REPLAY_FORMAT,
  REPLAY_VERSION,
  ReplayRecorder,
  withoutAttackValue,
};
