#!/usr/bin/env node
'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');
const { ReplayRecorder } = require('./replay-recorder.cjs');
const { STRATEGY_IMPLEMENTED, chooseCommand } = require('./strategy.cjs');

const SERVER_URL = process.env.CRAZY_CRASH_SERVER_URL
  || 'https://pre-young-hackathon.alibaba-inc.com';
const ACCESS_KEY = process.env.CRAZY_CRASH_ACCESS_KEY;
const BOT_VERSION = process.env.BOT_VERSION || 'participant-starter-v1';
const RETRY_MS = Math.max(500, Number(process.env.ROOM_RETRY_MS) || 2000);
const COMMAND_INTERVAL_MS = Math.max(80, Number(process.env.COMMAND_INTERVAL_MS) || 100);
const BATTLE_DATA_TIMEOUT_MS = Math.max(1000, Number(process.env.BATTLE_DATA_TIMEOUT_MS) || 5000);
const RUNTIME_DIR = process.env.CRAZY_CRASH_RUNTIME_DIR
  ? path.resolve(process.env.CRAZY_CRASH_RUNTIME_DIR)
  : path.join(__dirname, 'runtime');

if (!ACCESS_KEY) {
  throw new Error('缺少 CRAZY_CRASH_ACCESS_KEY。请双击启动脚本并输入报名平台发放的 AccessKey。');
}

const server = new URL(SERVER_URL);
const defaultWsProtocol = server.protocol === 'https:' ? 'wss:' : 'ws:';
const wsUrl = process.env.CRAZY_CRASH_WS_URL || `${defaultWsProtocol}//${server.host}/ai`;
const strategyHash = crypto.createHash('sha256')
  .update(fs.readFileSync(path.join(__dirname, 'strategy.cjs')))
  .digest('hex');

const SIMPLE_COMMANDS = new Set(['goForward', 'goBack', 'stop', 'steerBack']);
const TURN_COMMANDS = new Set(['turnLeft', 'turnRight']);
// 服务端用这两个关闭码表示“本次身份不可用，不要继续重连”：
// 1007 认证或元数据非法，1008 同一 AK 重复在线或中控主动下线。
const TERMINAL_CLOSE_CODES = new Set([1007, 1008]);

fs.mkdirSync(RUNTIME_DIR, { recursive: true });

let socket;
let reconnectTimer;
let roomRetryTimer;
let heartbeatTimer;
let battleDataTimer;
let shuttingDown = false;
let playing = false;
let botId = null;
let botName = '参赛 BOT';
let pendingAssignment = null;
let enteredRoomId = null;
let lastCommandAt = 0;
let lastStrategyErrorAt = 0;
let frameCount = 0;
let commandCount = 0;
// 当前正在进行的这一局的采集目录。
let currentCapture = null;
// 已经收到 matchFinished、还在等待 myBattleData 的那一局；三局两胜制下它可能
// 和 currentCapture 不是同一局，因此必须单独持有。
let settlementCapture = null;

function log(event, details = {}) {
  const record = { timestamp: new Date().toISOString(), event, botId, botName, ...details };
  const line = JSON.stringify(record);
  console.log(line);
  fs.appendFileSync(path.join(RUNTIME_DIR, 'events.jsonl'), `${line}\n`, 'utf8');
}

function status(message) {
  console.log(`\n[状态] ${message}\n`);
}

function send(payload) {
  if (!socket || socket.readyState !== WebSocket.OPEN) return false;
  socket.send(JSON.stringify(payload));
  return true;
}

function startHeartbeat() {
  clearInterval(heartbeatTimer);
  heartbeatTimer = setInterval(() => send({ commandType: 'botHeartbeat' }), 5000);
}

function safeSegment(value) {
  return String(value || 'unknown').replace(/[^A-Za-z0-9._-]/g, '_').slice(0, 120);
}

function writeJson(filePath, value) {
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`, 'utf8');
}

function appendCapture(capture, fileName, value) {
  if (!capture) return;
  fs.appendFileSync(path.join(capture.directory, fileName), `${JSON.stringify(value)}\n`, 'utf8');
}

function createCapture(matchCode, matchId, roomId) {
  const directory = path.join(
    RUNTIME_DIR,
    'matches',
    safeSegment(`${matchCode}-${matchId || Date.now()}`),
  );
  fs.mkdirSync(directory, { recursive: true });
  return {
    directory,
    matchCode,
    matchId: matchId == null ? null : matchId,
    roomId: roomId || null,
    startedAt: null,
    practice: false,
    settlement: null,
  };
}

function startCapture(message) {
  const assignment = pendingAssignment || {};
  const matchCode = assignment.matchCode || enteredRoomId || `practice-${Date.now()}`;
  currentCapture = createCapture(matchCode, assignment.matchId, enteredRoomId);
  currentCapture.startedAt = new Date().toISOString();
  currentCapture.practice = assignment.matchType === 'PRACTICE';
  const metadata = {
    matchCode,
    matchId: currentCapture.matchId,
    roomId: enteredRoomId,
    botId,
    botName,
    startedAt: currentCapture.startedAt,
    matchType: assignment.matchType || null,
    roundNo: assignment.roundNo == null ? null : assignment.roundNo,
    // 正式赛一桌可能连打多局，gameNo/gamesPerTable 用来区分同一桌的第几局。
    gameNo: assignment.gameNo == null ? null : assignment.gameNo,
    gamesPerTable: assignment.gamesPerTable == null ? null : assignment.gamesPerTable,
    strategyHash,
    strategyImplemented: STRATEGY_IMPLEMENTED === true,
  };
  writeJson(path.join(currentCapture.directory, 'metadata.json'), metadata);
  currentCapture.replayRecorder = new ReplayRecorder({
    directory: currentCapture.directory,
    meta: {
      matchCode: metadata.matchCode,
      matchId: metadata.matchId,
      roomId: metadata.roomId,
      matchType: metadata.matchType,
      roundNo: metadata.roundNo,
      gameNo: metadata.gameNo,
      gamesPerTable: metadata.gamesPerTable,
      recordedAt: currentCapture.startedAt,
      recorderBot: { id: botId, name: botName },
      strategyHash,
    },
  });
  const receivedAt = Date.now();
  currentCapture.replayRecorder.start(message, receivedAt);
  appendCapture(currentCapture, 'frames.jsonl', {
    receivedAt,
    sourceTimestamp: message.timeStamp || message.timestamp || null,
    commandType: 'startGame',
    data: message.data || {},
  });
}

function finishCapture() {
  if (!currentCapture) return;
  const receivedAt = Date.now();
  // 服务端下发的 closeGame 只有 commandType，没有成绩数据。
  appendCapture(currentCapture, 'frames.jsonl', {
    receivedAt,
    commandType: 'closeGame',
  });
  writeJson(path.join(currentCapture.directory, 'capture-summary.json'), {
    matchCode: currentCapture.matchCode,
    matchId: currentCapture.matchId,
    roomId: currentCapture.roomId,
    startedAt: currentCapture.startedAt,
    closedAt: new Date().toISOString(),
    frameCount,
    commandCount,
  });
  if (currentCapture.replayRecorder) {
    const replayPath = currentCapture.replayRecorder.close(receivedAt);
    log('REPLAY_SAVED', {
      complete: false,
      matchCode: currentCapture.matchCode,
      path: replayPath,
    });
  }
}

function saveSettlement(message) {
  let capture = currentCapture;
  const sameMatch = capture && (message.matchId == null || capture.matchId == null
    || String(capture.matchId) === String(message.matchId));
  if (!sameMatch) {
    capture = createCapture(message.matchCode || 'match', message.matchId, message.roomId);
  }
  capture.practice = message.matchType === 'PRACTICE' || message.nextState === 'TRAINING';
  capture.settlement = message;
  writeJson(path.join(capture.directory, 'settlement.json'), message);
  if (capture.replayRecorder) {
    const replayPath = capture.replayRecorder.settle(message);
    log('REPLAY_SAVED', {
      complete: true,
      matchCode: capture.matchCode,
      path: replayPath,
    });
  }
  settlementCapture = capture;
}

function clearBattleDataTimer() {
  if (battleDataTimer) clearTimeout(battleDataTimer);
  battleDataTimer = null;
}

/** 结算收尾：自由赛在数据落盘后才申请下一场，正式赛只需回到大厅等待。 */
function finishSettlement() {
  clearBattleDataTimer();
  const capture = settlementCapture;
  settlementCapture = null;
  if (capture && capture.practice) {
    send({ commandType: 'readyForNextMatch' });
  }
}

function requestBattleData() {
  clearBattleDataTimer();
  if (!send({ commandType: 'getMyBattleData', limit: 100 })) {
    finishSettlement();
    return;
  }
  // 服务端异常或消息丢失时不能卡住自由赛的下一场申请。
  battleDataTimer = setTimeout(() => {
    log('BATTLE_DATA_TIMEOUT', {
      matchCode: settlementCapture && settlementCapture.matchCode,
    });
    finishSettlement();
  }, BATTLE_DATA_TIMEOUT_MS);
}

function handleBattleData(message) {
  const capture = settlementCapture;
  if (!capture) return;
  writeJson(path.join(capture.directory, 'battle-data.json'), message);
  log('BATTLE_DATA_SAVED', {
    matchCode: capture.matchCode,
    directory: capture.directory,
  });
  finishSettlement();
}

function clearRoomRetry() {
  if (roomRetryTimer) clearTimeout(roomRetryTimer);
  roomRetryTimer = null;
}

function leaveRoom() {
  playing = false;
  enteredRoomId = null;
  clearRoomRetry();
}

function scheduleRoomEnter(delay = RETRY_MS) {
  clearRoomRetry();
  if (!pendingAssignment || pendingAssignment.assignmentType !== 'MATCH'
    || !pendingAssignment.roomId) return;
  roomRetryTimer = setTimeout(() => {
    if (enteredRoomId === pendingAssignment.roomId) return;
    log('ROOM_ENTER_ATTEMPT', {
      roomId: pendingAssignment.roomId,
      matchCode: pendingAssignment.matchCode,
    });
    send({ commandType: 'aiEnterRoom', roomId: pendingAssignment.roomId });
  }, delay);
}

/** roundStarted 与 seriesGameStarted 都表示“可以进入这一桌当前这一局的房间了”。 */
function handleRoundStart(message, event) {
  pendingAssignment = message;
  if (message.roomId && message.roomId !== enteredRoomId) {
    enteredRoomId = null;
  }
  log(event, {
    roundNo: message.roundNo,
    matchCode: message.matchCode,
    roomId: message.roomId,
    gameNo: message.gameNo,
    gamesPerTable: message.gamesPerTable,
  });
  scheduleRoomEnter(0);
}

function normalizeCommand(command) {
  if (!command || typeof command !== 'object') {
    throw new Error('chooseCommand 必须返回动作对象');
  }
  const commandType = command.commandType;
  if (SIMPLE_COMMANDS.has(commandType)) return { commandType };
  if (TURN_COMMANDS.has(commandType)) {
    const speed = Number(command.data);
    if (!Number.isFinite(speed) || speed < 0.01 || speed > 0.1) {
      throw new Error(`${commandType}.data 必须是 0.01～0.1`);
    }
    return { commandType, data: String(speed) };
  }
  if (commandType === 'setAttackValue') {
    const attackValue = Number(command.data);
    if (!Number.isFinite(attackValue) || attackValue < 0 || attackValue > 1000) {
      throw new Error('setAttackValue.data 必须是 0～1000');
    }
    return { commandType, data: String(Math.round(attackValue)) };
  }
  throw new Error(`不支持的 commandType: ${String(commandType)}`);
}

function decideCommand(gameState) {
  try {
    return normalizeCommand(chooseCommand(gameState, botId));
  } catch (error) {
    if (Date.now() - lastStrategyErrorAt >= 1000) {
      lastStrategyErrorAt = Date.now();
      log('STRATEGY_ERROR', { message: error.message });
    }
    return { commandType: 'stop' };
  }
}

function handleMessage(message) {
  switch (message.commandType) {
    case 'botConnected':
      botId = message.botId;
      botName = message.botName || botName;
      leaveRoom();
      pendingAssignment = null;
      startHeartbeat();
      log('BOT_CONNECTED', { state: message.state, wsUrl });
      status(`${botName}（BOT ${botId}）已上线，正在大厅等待中控台分桌。`);
      if (STRATEGY_IMPLEMENTED !== true) {
        status('当前 strategy.cjs 仍是空白策略，进入比赛后只会原地停止。');
      }
      break;
    case 'roundAssigned':
      pendingAssignment = message;
      enteredRoomId = null;
      clearRoomRetry();
      if (message.assignmentType === 'BYE') {
        log('ROUND_BYE', { roundNo: message.roundNo, roundPoints: message.roundPoints });
        status(`第 ${message.roundNo} 轮轮空，无需进入房间。`);
      } else {
        log('ROUND_ASSIGNED', {
          roundNo: message.roundNo,
          matchCode: message.matchCode,
          roomId: message.roomId,
          tableNo: message.tableNo,
          seatNo: message.seatNo,
          gameNo: message.gameNo,
          gamesPerTable: message.gamesPerTable,
        });
        status(`已分配第 ${message.roundNo} 轮第 ${message.tableNo} 桌，等待主持人开赛。`);
      }
      break;
    case 'roundStarted':
      handleRoundStart(message, 'ROUND_STARTED');
      break;
    case 'seriesGameStarted':
      // 同一桌的下一局：房间号会变，必须重新入房。
      handleRoundStart(message, 'SERIES_GAME_STARTED');
      break;
    case 'roomEntered':
      enteredRoomId = message.roomId;
      clearRoomRetry();
      log('ROOM_ENTERED', { roomId: message.roomId });
      break;
    case 'startGame':
      playing = true;
      frameCount = 0;
      commandCount = 0;
      lastCommandAt = 0;
      startCapture(message);
      log('GAME_STARTED', {
        roomId: enteredRoomId,
        roundNo: pendingAssignment && pendingAssignment.roundNo,
        gameNo: pendingAssignment && pendingAssignment.gameNo,
      });
      status('比赛开始，正在调用 strategy.cjs。');
      break;
    case 'refreshData': {
      if (!playing) break;
      frameCount += 1;
      const receivedAt = Date.now();
      appendCapture(currentCapture, 'frames.jsonl', {
        receivedAt,
        sourceTimestamp: message.timestamp || message.timeStamp || null,
        commandType: 'refreshData',
        data: message.data || {},
      });
      if (currentCapture && currentCapture.replayRecorder) {
        currentCapture.replayRecorder.frame(message, receivedAt);
      }
      if (Date.now() - lastCommandAt < COMMAND_INTERVAL_MS) break;
      const command = decideCommand(message.data || {});
      if (send(command)) {
        lastCommandAt = Date.now();
        commandCount += 1;
        appendCapture(currentCapture, 'commands.jsonl', { sentAt: lastCommandAt, command });
      }
      break;
    }
    case 'closeGame':
      // 服务端在收到 closeGame 之前已经关闭房间，此后任何战斗指令都会被拒绝。
      playing = false;
      finishCapture();
      log('GAME_CLOSED', { roomId: enteredRoomId, frameCount, commandCount });
      break;
    case 'matchFinished': {
      playing = false;
      saveSettlement(message);
      requestBattleData();
      // 三局制的中间局结束后，服务端会紧接着下发下一局的 seriesGameStarted / roundStarted。
      const seriesContinues = message.nextState === 'WAITING_NEXT_GAME';
      enteredRoomId = null;
      clearRoomRetry();
      if (!seriesContinues) pendingAssignment = null;
      log('MATCH_FINISHED', {
        matchCode: message.matchCode,
        roundNo: message.roundNo,
        gameNo: message.gameNo,
        gamesPerTable: message.gamesPerTable,
        resultRank: message.resultRank,
        advancementStatus: message.advancementStatus,
        nextState: message.nextState,
      });
      status(seriesContinues
        ? `本桌第 ${message.gameNo}/${message.gamesPerTable} 局结束，等待同桌下一局开始。`
        : '本场已结算，正在保存个人战斗数据。');
      break;
    }
    case 'myBattleData':
      handleBattleData(message);
      break;
    case 'roundFinished':
      pendingAssignment = null;
      clearRoomRetry();
      log('ROUND_FINISHED', {
        roundNo: message.roundNo,
        resultRank: message.resultRank,
        advancementStatus: message.advancementStatus,
        nextState: message.nextState,
      });
      status(`第 ${message.roundNo} 轮结果：${message.advancementStatus}。`);
      break;
    case 'roundRestarted':
      leaveRoom();
      pendingAssignment = null;
      log('ROUND_RESTARTED', {
        roundNo: message.roundNo,
        previousPairingVersion: message.previousPairingVersion,
        pairingVersion: message.pairingVersion,
      });
      status('主持人重开了本轮，等待新的分桌事件。');
      break;
    case 'botWaiting':
      leaveRoom();
      pendingAssignment = null;
      log('BOT_WAITING', { reason: message.reason });
      status('中控已让全部 BOT 回到大厅等待。');
      break;
    case 'botReady':
      log('BOT_READY', { state: message.state });
      status('战斗数据已保存，已重新进入自由赛等待队列。');
      break;
    case 'error':
      log('SERVER_ERROR', {
        code: message.code,
        message: message.message,
        roomId: message.roomId,
      });
      if (message.code === 'ROOM_NOT_OPEN') {
        scheduleRoomEnter(Number(message.retryAfterMs) || RETRY_MS);
        break;
      }
      if (message.code === 'BOT_NOT_ASSIGNED' || message.code === 'ROOM_ID_INVALID') {
        // 不是本队的房间，继续重试只会刷错误日志；保持在线等待中控重新分桌。
        clearRoomRetry();
        pendingAssignment = null;
        status(`服务端拒绝进入房间（${message.code}），保持在线等待中控重新分桌。`);
        break;
      }
      if (message.code === 'BOT_ALREADY_ONLINE') {
        status('同一 AccessKey 已有另一个进程在线，请关闭旧窗口后再启动。');
      }
      break;
    default:
      break;
  }
}

function closeHint(code, reason) {
  if (reason.includes('BOT_ALREADY_ONLINE')) {
    return '同一 AccessKey 已有另一个进程在线。关闭旧窗口后再重新启动，不要循环重连。';
  }
  if (reason.includes('BOT_AUTH_FAILED')) {
    return '身份校验失败。请确认输入的是报名平台发放的 AccessKey，注意区分大小写且不要包含多余空格。';
  }
  if (reason.includes('BOT_METADATA_INVALID')) {
    return 'botVersion 或 strategyHash 超出长度限制，请恢复开发包默认值后重试。';
  }
  return `服务端已终止本连接（${code}${reason ? ' ' + reason : ''}），不再自动重连。`;
}

function connect() {
  clearTimeout(reconnectTimer);
  socket = new WebSocket(wsUrl);
  socket.on('open', () => {
    log('SOCKET_OPEN', { wsUrl });
    send({
      commandType: 'botConnect',
      accessKey: ACCESS_KEY,
      botVersion: BOT_VERSION,
      strategyHash,
    });
  });
  socket.on('message', raw => {
    try {
      handleMessage(JSON.parse(raw.toString()));
    } catch (error) {
      log('MESSAGE_INVALID', { message: error.message });
    }
  });
  socket.on('close', (code, reason) => {
    const text = reason ? reason.toString() : '';
    leaveRoom();
    pendingAssignment = null;
    clearBattleDataTimer();
    clearInterval(heartbeatTimer);
    log('SOCKET_CLOSED', { code, reason: text });
    if (shuttingDown) return;
    if (TERMINAL_CLOSE_CODES.has(code)) {
      shuttingDown = true;
      status(closeHint(code, text));
      return;
    }
    reconnectTimer = setTimeout(connect, 1500);
  });
  socket.on('error', error => log('SOCKET_ERROR', { message: error.message }));
}

function shutdown() {
  if (shuttingDown) return;
  shuttingDown = true;
  clearTimeout(reconnectTimer);
  clearRoomRetry();
  clearBattleDataTimer();
  clearInterval(heartbeatTimer);
  if (playing) send({ commandType: 'stop' });
  if (socket && socket.readyState <= WebSocket.OPEN) {
    socket.close(1000, 'Bot shutdown');
  }
}

process.once('SIGINT', shutdown);
process.once('SIGTERM', shutdown);
connect();
