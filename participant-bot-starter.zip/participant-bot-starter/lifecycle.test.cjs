'use strict';

const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const { once } = require('events');
const { WebSocketServer } = require('ws');

const TEST_ACCESS_KEY = 'test-only-access-key-must-not-leak';
const runtimeDir = fs.mkdtempSync(path.join(os.tmpdir(), 'crazy-crash-starter-'));
const received = [];
const waiters = [];
const GAMEPLAY_COMMANDS = new Set([
  'goForward', 'goBack', 'turnLeft', 'turnRight',
  'stop', 'steerBack', 'setAttackValue',
]);

// 真实协议下发的一帧：大屏与服务端都不再包含 attackValue。
function frame(overrides) {
  return Object.assign({
    id: 1001,
    name: '测试参赛队',
    active: true,
    position: { x: 720, y: 410 },
    velocity: { x: 0, y: 0 },
    angle: 0,
    speed: 0,
    angularSpeed: 0,
    width: 70,
    height: 64,
    moveState: 0,
    dirState: 0,
    rebounding: false,
    reboundAngle: 0,
    attacking: false,
    invincible: false,
    energy: 1000,
    score: 10,
    deathCount: 0,
    survivalTime: 3,
  }, overrides);
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function receive(message) {
  received.push(message);
  for (let index = waiters.length - 1; index >= 0; index -= 1) {
    const waiter = waiters[index];
    if (waiter.predicate(message)) {
      waiters.splice(index, 1);
      clearTimeout(waiter.timer);
      waiter.resolve(message);
    }
  }
}

function waitForMessage(predicate, description, timeoutMs = 3000) {
  const existing = received.find(predicate);
  if (existing) return Promise.resolve(existing);
  return new Promise((resolve, reject) => {
    const waiter = { predicate, resolve, timer: null };
    waiter.timer = setTimeout(() => {
      const index = waiters.indexOf(waiter);
      if (index >= 0) waiters.splice(index, 1);
      reject(new Error(`Timed out waiting for ${description}`));
    }, timeoutMs);
    waiters.push(waiter);
  });
}

function waitForExit(child, timeoutMs = 3000) {
  return Promise.race([
    once(child, 'exit'),
    new Promise((_, reject) => setTimeout(
      () => reject(new Error('Bot process did not exit')),
      timeoutMs,
    )),
  ]);
}

function assertCaptureFiles(matchDir, fileNames) {
  for (const fileName of fileNames) {
    assert(fs.existsSync(path.join(matchDir, fileName)), `缺少战斗文件 ${matchDir}/${fileName}`);
  }
}

async function main() {
  const server = new WebSocketServer({ port: 0 });
  await once(server, 'listening');
  const port = server.address().port;
  const connectionPromise = once(server, 'connection');
  const child = spawn(process.execPath, [path.join(__dirname, 'bot.cjs')], {
    cwd: __dirname,
    env: {
      ...process.env,
      CRAZY_CRASH_ACCESS_KEY: TEST_ACCESS_KEY,
      CRAZY_CRASH_SERVER_URL: `http://127.0.0.1:${port}`,
      CRAZY_CRASH_RUNTIME_DIR: runtimeDir,
      COMMAND_INTERVAL_MS: '80',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let stdout = '';
  let stderr = '';
  child.stdout.on('data', chunk => { stdout += chunk.toString(); });
  child.stderr.on('data', chunk => { stderr += chunk.toString(); });

  const [client] = await connectionPromise;
  client.on('message', raw => receive(JSON.parse(raw.toString())));
  const sendToBot = payload => client.send(JSON.stringify(payload));

  const connected = await waitForMessage(
    message => message.commandType === 'botConnect',
    'botConnect',
  );
  assert.strictEqual(connected.accessKey, TEST_ACCESS_KEY);
  assert.strictEqual(connected.botVersion, 'participant-starter-v1');
  assert.match(connected.strategyHash, /^[a-f0-9]{64}$/);

  sendToBot({
    commandType: 'botConnected',
    botId: 1001,
    botName: '测试参赛队',
    state: 'LOBBY',
    serverTime: Date.now(),
  });

  // ---- 正式赛：一桌三局，每一局都是独立的 matchId 和独立的房间 ----
  const assignment = {
    tournamentCode: 'test-tournament',
    tournamentName: '测试赛',
    roundNo: 1,
    pairingVersion: 1,
    assignmentType: 'MATCH',
    tableNo: 1,
    seatNo: 1,
    roundPoints: 0,
    gamesPerTable: 3,
    gamesFinished: 0,
    matchId: 77,
    matchCode: 'test-r01-t01-g01',
    roomId: 'test-r01-t01-g01',
    gameNo: 1,
  };
  sendToBot(Object.assign({ commandType: 'roundAssigned' }, assignment));

  await delay(120);
  assert.strictEqual(
    received.some(message => message.commandType === 'aiEnterRoom'),
    false,
    'roundAssigned 后不得提前入房',
  );

  sendToBot(Object.assign({ commandType: 'roundStarted' }, assignment));
  const roomEntry = await waitForMessage(
    message => message.commandType === 'aiEnterRoom',
    'aiEnterRoom',
  );
  assert.strictEqual(roomEntry.roomId, 'test-r01-t01-g01');
  assert.strictEqual(Object.prototype.hasOwnProperty.call(roomEntry, 'accessKey'), false);

  sendToBot({ commandType: 'roomEntered', botId: 1001, roomId: 'test-r01-t01-g01' });
  sendToBot({
    commandType: 'startGame',
    timeStamp: Date.now(),
    data: { rabbits: [frame()], map: { width: 1440, height: 820, borders: [], blocks: [] } },
  });
  sendToBot({
    commandType: 'refreshData',
    timestamp: Date.now(),
    data: { rabbits: [frame()], goldCarrot: {} },
  });
  const gameplayCommand = await waitForMessage(
    message => GAMEPLAY_COMMANDS.has(message.commandType),
    'strategy gameplay command',
  );

  // 服务端的 closeGame 只有 commandType，成绩由大屏单独上报。
  sendToBot({ commandType: 'closeGame' });
  sendToBot({
    commandType: 'matchFinished',
    matchId: 77,
    matchCode: 'test-r01-t01-g01',
    roundNo: 1,
    roomId: 'test-r01-t01-g01',
    gameNo: 1,
    gamesPerTable: 3,
    resultRank: 2,
    advancementStatus: 'PENDING',
    nextState: 'WAITING_NEXT_GAME',
    result: {
      seriesFinished: false,
      ranking: [{
        botId: 1001, rank: 2, score: 9, deathCount: 0,
        forestHeartCount: 1, survivalTime: 180, victoryTime: null, points: 3,
      }],
    },
  });
  await waitForMessage(
    message => message.commandType === 'getMyBattleData',
    'getMyBattleData',
  );
  sendToBot({
    commandType: 'myBattleData',
    botId: 1001,
    records: [{ matchCode: 'test-r01-t01-g01', rank: 2 }],
    tournaments: [],
  });

  await delay(120);
  assert.strictEqual(
    received.some(message => message.commandType === 'readyForNextMatch'),
    false,
    '正式赛结算后不得申请自由赛下一场',
  );

  // 同一桌的第二局：房间号改变，BOT 必须重新入房。
  const nextGame = Object.assign({}, assignment, {
    matchId: 78,
    matchCode: 'test-r01-t01-g02',
    roomId: 'test-r01-t01-g02',
    gameNo: 2,
    gamesFinished: 1,
  });
  sendToBot(Object.assign({ commandType: 'seriesGameStarted' }, nextGame));
  sendToBot(Object.assign({ commandType: 'roundStarted' }, nextGame));
  const secondRoomEntry = await waitForMessage(
    message => message.commandType === 'aiEnterRoom' && message.roomId === 'test-r01-t01-g02',
    'aiEnterRoom for the second game',
  );
  assert.strictEqual(secondRoomEntry.roomId, 'test-r01-t01-g02');

  sendToBot({ commandType: 'roomEntered', botId: 1001, roomId: 'test-r01-t01-g02' });
  sendToBot({
    commandType: 'startGame',
    timeStamp: Date.now(),
    data: { rabbits: [frame()], map: { width: 1440, height: 820, borders: [], blocks: [] } },
  });
  sendToBot({
    commandType: 'refreshData',
    timestamp: Date.now(),
    data: { rabbits: [frame({ energy: 800 })], goldCarrot: { x: 760, y: 220 } },
  });
  sendToBot({ commandType: 'closeGame' });
  sendToBot({
    commandType: 'matchFinished',
    matchId: 78,
    matchCode: 'test-r01-t01-g02',
    roundNo: 1,
    roomId: 'test-r01-t01-g02',
    gameNo: 2,
    gamesPerTable: 3,
    resultRank: 1,
    advancementStatus: 'ADVANCED',
    nextState: 'WAITING_NEXT_ROUND',
    result: { seriesFinished: true, ranking: [], aggregateRanking: [] },
  });
  await waitForMessage(
    message => message.commandType === 'getMyBattleData',
    'getMyBattleData for the second game',
  );
  sendToBot({
    commandType: 'myBattleData',
    botId: 1001,
    records: [{ matchCode: 'test-r01-t01-g02', rank: 1 }],
    tournaments: [],
  });
  sendToBot({
    commandType: 'roundFinished',
    tournamentCode: 'test-tournament',
    roundNo: 1,
    resultRank: 1,
    advancementStatus: 'ADVANCED',
    nextState: 'WAITING_NEXT_ROUND',
  });

  // ---- 自由赛：结算并保存数据后才申请下一场 ----
  const practiceAssignment = {
    tournamentCode: 'freeplay-test',
    matchType: 'PRACTICE',
    sessionId: 'freeplay-test',
    batchId: 'freeplay-test-b001',
    roundNo: 1,
    assignmentType: 'MATCH',
    tableNo: 1,
    seatNo: 1,
    matchId: 91,
    matchCode: 'freeplay-test-b001-t01',
    roomId: 'freeplay-test-b001-t01',
  };
  sendToBot(Object.assign({ commandType: 'roundAssigned' }, practiceAssignment));
  sendToBot(Object.assign({ commandType: 'roundStarted' }, practiceAssignment));
  await waitForMessage(
    message => message.commandType === 'aiEnterRoom'
      && message.roomId === 'freeplay-test-b001-t01',
    'aiEnterRoom for the practice table',
  );
  sendToBot({ commandType: 'roomEntered', botId: 1001, roomId: 'freeplay-test-b001-t01' });
  sendToBot({
    commandType: 'startGame',
    timeStamp: Date.now(),
    data: { rabbits: [frame()], map: { width: 1440, height: 820, borders: [], blocks: [] } },
  });
  sendToBot({
    commandType: 'refreshData',
    timestamp: Date.now(),
    data: { rabbits: [frame()], goldCarrot: null },
  });
  sendToBot({ commandType: 'closeGame' });
  sendToBot({
    commandType: 'matchFinished',
    matchId: 91,
    matchCode: 'freeplay-test-b001-t01',
    matchType: 'PRACTICE',
    nextState: 'TRAINING',
    roomId: 'freeplay-test-b001-t01',
    result: { ranking: [{ botId: 1001, rank: 4, score: 3 }] },
  });
  await waitForMessage(
    message => message.commandType === 'getMyBattleData',
    'getMyBattleData for the practice match',
  );
  sendToBot({
    commandType: 'myBattleData',
    botId: 1001,
    records: [{ matchCode: 'freeplay-test-b001-t01', rank: 4 }],
    tournaments: [],
  });
  await waitForMessage(
    message => message.commandType === 'readyForNextMatch',
    'readyForNextMatch',
  );
  sendToBot({ commandType: 'botReady', botId: 1001, state: 'LOBBY_READY' });

  await delay(80);
  child.kill('SIGTERM');
  await waitForExit(child);
  await new Promise(resolve => server.close(resolve));

  const combinedOutput = `${stdout}\n${stderr}`;
  assert.strictEqual(combinedOutput.includes(TEST_ACCESS_KEY), false, 'AK 不得出现在终端输出');
  const eventLog = fs.readFileSync(path.join(runtimeDir, 'events.jsonl'), 'utf8');
  assert.strictEqual(eventLog.includes(TEST_ACCESS_KEY), false, 'AK 不得写入运行日志');

  const captureFiles = [
    'metadata.json',
    'frames.jsonl',
    'commands.jsonl',
    'capture-summary.json',
    'replay.ccreplay.json',
    'settlement.json',
    'battle-data.json',
  ];
  const firstGameDir = path.join(runtimeDir, 'matches', 'test-r01-t01-g01-77');
  const secondGameDir = path.join(runtimeDir, 'matches', 'test-r01-t01-g02-78');
  const practiceDir = path.join(runtimeDir, 'matches', 'freeplay-test-b001-t01-91');
  assertCaptureFiles(firstGameDir, captureFiles);
  assertCaptureFiles(secondGameDir, captureFiles);
  assertCaptureFiles(practiceDir, captureFiles);

  const firstMetadata = JSON.parse(fs.readFileSync(path.join(firstGameDir, 'metadata.json'), 'utf8'));
  const secondMetadata = JSON.parse(fs.readFileSync(path.join(secondGameDir, 'metadata.json'), 'utf8'));
  assert.strictEqual(firstMetadata.gameNo, 1, '第一局的 gameNo 应为 1');
  assert.strictEqual(secondMetadata.gameNo, 2, '第二局的 gameNo 应为 2');
  assert.strictEqual(secondMetadata.gamesPerTable, 3, '应记录本桌总局数');

  const firstSettlement = JSON.parse(fs.readFileSync(path.join(firstGameDir, 'settlement.json'), 'utf8'));
  assert.strictEqual(firstSettlement.matchId, 77, '每一局的结算必须落在自己的目录里');
  const secondBattleData = JSON.parse(fs.readFileSync(path.join(secondGameDir, 'battle-data.json'), 'utf8'));
  assert.strictEqual(secondBattleData.records[0].matchCode, 'test-r01-t01-g02');

  assert.deepStrictEqual(
    JSON.parse(fs.readFileSync(path.join(firstGameDir, 'commands.jsonl'), 'utf8')
      .trim().split('\n')[0]).command,
    gameplayCommand,
  );
  const replay = JSON.parse(fs.readFileSync(
    path.join(practiceDir, 'replay.ccreplay.json'),
    'utf8',
  ));
  assert.strictEqual(replay.format, 'crazy-crash-replay');
  assert.strictEqual(replay.version, 1);
  assert.strictEqual(replay.end.complete, true);
  assert.strictEqual(replay.frames.length, 1);
  assert.strictEqual(replay.end.rankings[0].rank, 4);
  assert.strictEqual(JSON.stringify(replay).includes('attackValue'), false,
    '可分享回放不得包含任何玩家的 attackValue');
  assert.strictEqual(JSON.stringify(replay).includes(TEST_ACCESS_KEY), false,
    '可分享回放不得包含 AccessKey');

  fs.rmSync(runtimeDir, { recursive: true, force: true });
  console.log('lifecycle starter tests passed');
}

main().catch(error => {
  fs.rmSync(runtimeDir, { recursive: true, force: true });
  console.error(error);
  process.exitCode = 1;
});
