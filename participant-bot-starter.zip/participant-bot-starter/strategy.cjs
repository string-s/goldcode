'use strict';

/**
 * 参赛者只需要修改这个文件。
 *
 * 这里附带一个可直接运行的基准策略：
 * - hunter：优先追逐金萝卜，否则追逐最近的存活对手；
 * - runner：优先追逐金萝卜，否则尽量远离最近的存活对手；
 * - 靠近地图边缘时，两种模式都会先返回场地中心。
 *
 * 可通过 BOT_STYLE=hunter 或 BOT_STYLE=runner 选择风格，默认 hunter。
 */
const STRATEGY_IMPLEMENTED = true;
const style = process.env.BOT_STYLE === 'runner' ? 'runner' : 'hunter';
let decisionCount = 0;

function normalizedAngle(value) {
  let angle = value;
  while (angle > Math.PI) angle -= Math.PI * 2;
  while (angle < -Math.PI) angle += Math.PI * 2;
  return angle;
}

function distanceSquared(left, right) {
  const dx = Number(left.position.x) - Number(right.position.x);
  const dy = Number(left.position.y) - Number(right.position.y);
  return dx * dx + dy * dy;
}

function findMe(rabbits, botId) {
  const expected = String(botId);
  return rabbits.find((rabbit) => {
    const id = String(rabbit.id);
    // ai: 前缀兼容本地 sample 服务；生产协议通常直接使用 botId。
    return id === expected || id === `ai:${expected}`;
  });
}

function chooseTarget(gameState, me, rabbits) {
  const carrot = gameState && gameState.goldCarrot;
  if (carrot && Number(carrot.x) > 0 && Number(carrot.y) > 0) {
    return { position: { x: Number(carrot.x), y: Number(carrot.y) } };
  }

  const x = Number(me.position.x);
  const y = Number(me.position.y);
  const edgeMargin = 150;
  if (x < edgeMargin || x > 1440 - edgeMargin
    || y < edgeMargin || y > 820 - edgeMargin) {
    return { position: { x: 720, y: 410 } };
  }

  const opponents = rabbits.filter((rabbit) => rabbit !== me
    && rabbit.active !== false && rabbit.active !== 'false' && rabbit.position);
  opponents.sort((left, right) => distanceSquared(left, me) - distanceSquared(right, me));
  const nearest = opponents[0];
  if (!nearest) return { position: { x: 720, y: 410 } };

  if (style === 'runner') {
    return {
      position: {
        x: 1440 - Number(nearest.position.x),
        y: 820 - Number(nearest.position.y),
      },
    };
  }
  return nearest;
}

/**
 * 每约 100ms 调用一次，每次最多返回一个动作。
 *
 * @param {object} gameState 服务端最新 refreshData.data
 * @param {number|string} botId 服务端 botConnected 返回的本人 BOT ID
 * @returns {{commandType: string, data?: string}}
 */
function chooseCommand(gameState, botId) {
  decisionCount += 1;
  const rabbits = Array.isArray(gameState && gameState.rabbits)
    ? gameState.rabbits : [];
  const me = findMe(rabbits, botId);

  // 本人不存在或已淘汰时必须停止，避免向房间发送无效动作。
  if (!me || me.active === false || me.active === 'false' || !me.position
    || !Number.isFinite(Number(me.position.x)) || !Number.isFinite(Number(me.position.y))) {
    return { commandType: 'stop' };
  }

  const target = chooseTarget(gameState, me, rabbits);
  const desiredAngle = Math.atan2(
    Number(target.position.y) - Number(me.position.y),
    Number(target.position.x) - Number(me.position.x),
  );
  const currentAngle = Number.isFinite(Number(me.angle)) ? Number(me.angle) : 0;
  const delta = normalizedAngle(desiredAngle - currentAngle);

  if (Math.abs(delta) > 0.18) {
    return {
      commandType: delta > 0 ? 'turnRight' : 'turnLeft',
      data: style === 'runner' ? '0.065' : '0.05',
    };
  }
  // 转向指令会持续生效，周期性回正后再继续前进。
  if (decisionCount % 7 === 0) {
    return { commandType: 'steerBack' };
  }
  return { commandType: 'goForward' };
}

module.exports = { STRATEGY_IMPLEMENTED, chooseCommand };
