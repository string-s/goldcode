@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"

echo ========================================
echo   疯狂 Geek 兔 · 参赛 BOT 开发包
echo ========================================
echo 连接与分桌链路已提供；战斗动作需要你修改 strategy.cjs。
echo 关闭本窗口即可让 BOT 下线。
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo 未检测到 Node.js 18+。请先安装：https://nodejs.org/
  pause
  exit /b 1
)

if not exist "node_modules\ws" (
  echo 首次运行，正在自动安装 WebSocket 依赖...
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo 依赖安装失败，请检查网络后重试。
    pause
    exit /b 1
  )
)

for /f "usebackq delims=" %%A in (`powershell -NoProfile -Command "$s=Read-Host '请输入报名平台发放的 AccessKey（输入不会显示或保存）' -AsSecureString; $b=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($s); try {[Runtime.InteropServices.Marshal]::PtrToStringBSTR($b)} finally {[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b)}"`) do set "CRAZY_CRASH_ACCESS_KEY=%%A"

if not defined CRAZY_CRASH_ACCESS_KEY (
  echo AccessKey 不能为空。
  pause
  exit /b 1
)

echo 正在连接比赛服务...
node bot.cjs
set "BOT_STATUS=%ERRORLEVEL%"
set "CRAZY_CRASH_ACCESS_KEY="

echo.
if "%BOT_STATUS%"=="0" (
  echo BOT 已下线。
) else (
  echo BOT 已退出，状态码：%BOT_STATUS%
)
pause
exit /b %BOT_STATUS%
