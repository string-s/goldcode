'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { STRATEGY_IMPLEMENTED, chooseCommand } = require('./strategy.cjs');

const SIMPLE_COMMANDS = new Set(['goForward', 'goBack', 'stop', 'steerBack']);
const TURN_COMMANDS = new Set(['turnLeft', 'turnRight']);

function assertLegalCommand(command) {
  assert(command && typeof command === 'object', '策略必须返回动作对象');
  if (SIMPLE_COMMANDS.has(command.commandType)) return;
  if (TURN_COMMANDS.has(command.commandType)) {
    const speed = Number(command.data);
    assert(Number.isFinite(speed) && speed >= 0.01 && speed <= 0.1,
      '转向速度必须在 0.01～0.1');
    return;
  }
  if (command.commandType === 'setAttackValue') {
    const value = Number(command.data);
    assert(Number.isFinite(value) && value >= 0 && value <= 1000,
      '攻击预设必须在 0～1000');
    return;
  }
  assert.fail(`非法动作：${String(command.commandType)}`);
}

function collectKeys(value, keys = new Set()) {
  if (Array.isArray(value)) {
    value.forEach(item => collectKeys(item, keys));
  } else if (value && typeof value === 'object') {
    Object.keys(value).forEach((key) => {
      keys.add(key);
      collectKeys(value[key], keys);
    });
  }
  return keys;
}

assert.strictEqual(typeof STRATEGY_IMPLEMENTED, 'boolean',
  'STRATEGY_IMPLEMENTED 必须是 boolean');
assert.strictEqual(STRATEGY_IMPLEMENTED, true,
  '当前分支应附带可以实际移动和转向的基准策略');

assert.deepStrictEqual(
  chooseCommand({ rabbits: [] }, 1001),
  { commandType: 'stop' },
  '找不到本人时必须停止',
);

// 样例帧必须和真实协议一致：服务端与大屏都不再下发 attackValue。
const sampleFrame = JSON.parse(fs.readFileSync(
  path.join(__dirname, 'examples', 'sample-refresh-data.json'), 'utf8'));
assert.strictEqual(
  collectKeys(sampleFrame).has('attackValue'),
  false,
  'examples/sample-refresh-data.json 不能再出现 attackValue',
);
assertLegalCommand(chooseCommand(sampleFrame, sampleFrame.rabbits[0].id));

const sampleState = {
  rabbits: [
    {
      id: 1001,
      active: true,
      position: { x: 720, y: 410 },
      angle: 0,
      energy: 1000,
      score: 10,
      deathCount: 0,
      survivalTime: 12,
    },
    {
      id: 1002,
      active: true,
      position: { x: 900, y: 410 },
      angle: Math.PI,
      energy: 1000,
      score: 10,
      deathCount: 0,
      survivalTime: 12,
    },
  ],
  goldCarrot: { x: 760, y: 200 },
};

const sampleCommand = chooseCommand(sampleState, 1001);
assertLegalCommand(sampleCommand);
assert(
  sampleCommand.commandType === 'turnLeft' || sampleCommand.commandType === 'turnRight',
  '面向场地右侧、金萝卜在上方时应主动转向目标',
);

// 本人已淘汰时必须停止：帧里仍会带上这只兔子，但 active=false。
assert.deepStrictEqual(chooseCommand({
  rabbits: [Object.assign({}, sampleState.rabbits[0], { active: false, energy: 0, score: 0 })],
  goldCarrot: null,
}, 1001), { commandType: 'stop' });

// 本地 sample 服务会给兔子 ID 增加 ai: 前缀，策略仍应识别本人。
assertLegalCommand(chooseCommand({
  rabbits: [Object.assign({}, sampleState.rabbits[0], { id: 'ai:1001' })],
  goldCarrot: null,
}, 1001));

const source = fs.readFileSync(path.join(__dirname, 'strategy.cjs'), 'utf8');
// 只禁止“从帧里读对手/自己的攻击预设”，不禁止把自己的预设存进本地状态。
const framePropertyAccess = source
  .replace(/setAttackValue/g, '')
  .match(/\b(rabbit|rabbits\[[^\]]*\]|me|enemy|target|opponent|self)\s*\.\s*attackValue\b/);
assert.strictEqual(
  framePropertyAccess,
  null,
  `协议帧不再下发 attackValue，不能读取 ${framePropertyAccess && framePropertyAccess[0]}`,
);

if (STRATEGY_IMPLEMENTED === false) {
  assert.deepStrictEqual(
    sampleCommand,
    { commandType: 'stop' },
    '空白模板必须保持原地停止，参赛者需要自行实现动作',
  );
  assert(source.includes('TODO（参赛者实现）'), '空白模板必须保留明确的实现入口');
} else {
  assert(!source.includes('const STRATEGY_IMPLEMENTED = false'),
    '策略已实现时必须把 STRATEGY_IMPLEMENTED 改为 true');
}

console.log(`strategy tests passed (${STRATEGY_IMPLEMENTED ? 'implemented' : 'starter'})`);
