#!/bin/zsh

set -u

BOT_DIR="${0:A:h}"
NODE_BIN="$(command -v node 2>/dev/null || true)"
NPM_BIN="$(command -v npm 2>/dev/null || true)"

if [[ -z "$NODE_BIN" && -x '/opt/homebrew/bin/node' ]]; then
    NODE_BIN='/opt/homebrew/bin/node'
fi
if [[ -z "$NPM_BIN" && -x '/opt/homebrew/bin/npm' ]]; then
    NPM_BIN='/opt/homebrew/bin/npm'
fi
if [[ -z "$NODE_BIN" && -x '/usr/local/bin/node' ]]; then
    NODE_BIN='/usr/local/bin/node'
fi
if [[ -z "$NPM_BIN" && -x '/usr/local/bin/npm' ]]; then
    NPM_BIN='/usr/local/bin/npm'
fi

clear
print '========================================'
print '  疯狂 Geek 兔 · 参赛 BOT 开发包'
print '========================================'
print '连接与分桌链路已提供；战斗动作需要你修改 strategy.cjs。'
print '关闭本窗口即可让 BOT 下线。'
print ''

if [[ -z "$NODE_BIN" || -z "$NPM_BIN" ]]; then
    print -u2 '未检测到 Node.js 18+。请先安装：https://nodejs.org/'
    read '?按回车关闭...'
    exit 1
fi

cd "$BOT_DIR" || exit 1

if [[ ! -d 'node_modules/ws' ]]; then
    print '首次运行，正在自动安装 WebSocket 依赖...'
    "$NPM_BIN" install --no-audit --no-fund || {
        print -u2 '依赖安装失败，请检查网络后重试。'
        read '?按回车关闭...'
        exit 1
    }
fi

read -s '?请输入报名平台发放的 AccessKey（输入不会显示或保存）：' CRAZY_CRASH_ACCESS_KEY
print ''
if [[ -z "$CRAZY_CRASH_ACCESS_KEY" ]]; then
    print -u2 'AccessKey 不能为空。'
    read '?按回车关闭...'
    exit 1
fi
export CRAZY_CRASH_ACCESS_KEY

print '正在连接比赛服务...'
"$NODE_BIN" bot.cjs
BOT_STATUS=$?
unset CRAZY_CRASH_ACCESS_KEY

if (( BOT_STATUS == 0 )); then
    print '\nBOT 已下线。'
else
    print -u2 "\nBOT 已退出，状态码：$BOT_STATUS"
fi
read '?按回车关闭...'
exit "$BOT_STATUS"
